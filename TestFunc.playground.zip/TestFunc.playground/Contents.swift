import UIKit

var inputFirst = [1, 2, 3, 4, 5, 6, 7]
var inputSecond = [-1, -100, 3, 99]
let k1 = 3
let k2 = 2


// FUNC #1
func rotate(_ nums: inout [Int], _ k: Int) -> [Int] {
    for _ in 1...k {
        let lastNum = nums.removeLast()
        nums.insert(lastNum, at: 0)
    }
    return nums
}
let result = rotate(&inputSecond, k2)

// FUNC #2
//func rotate(_ nums: inout [Int], _ k: Int) -> Array<Int>.SubSequence {
//    let lastNums = nums.dropFirst(nums.count - k)
//    let firstNums = nums.dropLast(k)
//
//    return lastNums + firstNums
//}
//let result = rotate(&inputFirst, k1)





